package com.example.localvpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val requestCode = 410

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 60, 36, 36)
        }
        val title = TextView(this).apply {
            text = "LOCAL VPN"
            textSize = 28f
        }
        status = TextView(this).apply {
            text = "محافظت محلی DNS خاموش است"
            textSize = 17f
            setPadding(0, 28, 0, 28)
        }
        val start = Button(this).apply {
            text = "روشن کردن"
            setOnClickListener {
                val prepare = VpnService.prepare(this@MainActivity)
                if (prepare != null) startActivityForResult(prepare, requestCode)
                else onActivityResult(requestCode, RESULT_OK, null)
            }
        }
        val stop = Button(this).apply {
            text = "خاموش کردن"
            setOnClickListener {
                startService(Intent(this@MainActivity, LocalVpnService::class.java).setAction(LocalVpnService.ACTION_STOP))
                status.text = "درخواست خاموش‌کردن ارسال شد"
            }
        }
        val note = TextView(this).apply {
            text = "این نسخه آزمایشی فقط درخواست‌های DNS را از فیلتر محلی عبور می‌دهد. IP و کشور را تغییر نمی‌دهد و محدودیت شبکه را دور نمی‌زند."
            textSize = 14f
            setPadding(0, 24, 0, 0)
        }
        layout.addView(title); layout.addView(status); layout.addView(start); layout.addView(stop); layout.addView(note)
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK) {
            startService(Intent(this, LocalVpnService::class.java).setAction(LocalVpnService.ACTION_START))
            status.text = "VPN محلی فعال شد (در صورت نمایش اعلان سیستم)"
        }
    }
}

package com.example.localvpn

import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.content.Intent
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Minimal DNS-only local VPN prototype.
 * It routes the synthetic DNS address through TUN, blocks a small built-in
 * list of ad/tracker hostnames, and forwards other DNS queries to 1.1.1.1.
 */
class LocalVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.example.localvpn.START"
        const val ACTION_STOP = "com.example.localvpn.STOP"
        private const val DNS_IP = "10.77.0.2"
    }

    private var tun: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopVpn()
            ACTION_START -> startVpn()
        }
        return START_NOT_STICKY
    }

    private fun startVpn() {
        if (running.get()) return
        try {
            tun = Builder()
                .setSession("Local VPN DNS Filter")
                .addAddress("10.77.0.1", 32)
                .addDnsServer(DNS_IP)
                .addRoute(DNS_IP, 32)
                .setMtu(1500)
                .establish()
            if (tun == null) return
            running.set(true)
            thread(name = "LocalVpnDns") { packetLoop() }
        } catch (_: Exception) {
            stopVpn()
        }
    }

    private fun packetLoop() {
        val fd = tun ?: return
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buffer = ByteArray(32767)
        while (running.get()) {
            try {
                val length = input.read(buffer)
                if (length <= 0) continue
                val response = handleIpv4Udp(buffer, length) ?: continue
                output.write(response)
            } catch (_: Exception) {
                if (running.get()) stopVpn()
                break
            }
        }
    }

    private fun handleIpv4Udp(packet: ByteArray, length: Int): ByteArray? {
        if (length < 28 || (packet[0].toInt() ushr 4 and 0xF) != 4) return null
        val ihl = (packet[0].toInt() and 0xF) * 4
        if (length < ihl + 8 || packet[9].toInt() != 17) return null
        val udpLen = u16(packet, ihl + 4)
        if (udpLen < 8 || ihl + udpLen > length) return null
        val dnsStart = ihl + 8
        val dnsLen = udpLen - 8
        if (dnsLen < 12) return null
        val query = packet.copyOfRange(dnsStart, dnsStart + dnsLen)
        val host = readQName(query) ?: return null
        val dnsReply = if (isBlocked(host)) blockedReply(query) else forwardDns(query) ?: return null

        val src = packet.copyOfRange(12, 16)
        val dst = packet.copyOfRange(16, 20)
        val srcPort = packet.copyOfRange(ihl, ihl + 2)
        val dstPort = packet.copyOfRange(ihl + 2, ihl + 4)
        val total = 20 + 8 + dnsReply.size
        val out = ByteArray(total)
        out[0] = 0x45
        put16(out, 2, total)
        out[8] = 64
        out[9] = 17
        System.arraycopy(dst, 0, out, 12, 4)
        System.arraycopy(src, 0, out, 16, 4)
        System.arraycopy(dstPort, 0, out, 20, 2)
        System.arraycopy(srcPort, 0, out, 22, 2)
        put16(out, 24, 8 + dnsReply.size)
        System.arraycopy(dnsReply, 0, out, 28, dnsReply.size)
        put16(out, 10, checksum(out, 0, 20))
        return out
    }

    private fun forwardDns(query: ByteArray): ByteArray? {
        return try {
            DatagramSocket().use { socket ->
                protect(socket)
                socket.soTimeout = 4000
                val address = InetAddress.getByName("1.1.1.1")
                socket.send(DatagramPacket(query, query.size, address, 53))
                val data = ByteArray(4096)
                val reply = DatagramPacket(data, data.size)
                socket.receive(reply)
                data.copyOf(reply.length)
            }
        } catch (_: Exception) { null }
    }

    private fun readQName(msg: ByteArray): String? {
        return try {
            var p = 12
            val labels = ArrayList<String>()
            while (p < msg.size) {
                val n = msg[p++].toInt() and 0xff
                if (n == 0) break
                if (n > 63 || p + n > msg.size) return null
                labels.add(String(msg, p, n, Charsets.US_ASCII))
                p += n
            }
            labels.joinToString(".").lowercase()
        } catch (_: Exception) { null }
    }

    private fun isBlocked(host: String): Boolean {
        val blocked = listOf("doubleclick.net", "googlesyndication.com", "adservice.google.com",
            "googletagmanager.com", "google-analytics.com", "facebook.net")
        return blocked.any { host == it || host.endsWith(".$it") }
    }

    private fun blockedReply(query: ByteArray): ByteArray {
        val reply = query.copyOf()
        reply[2] = 0x81.toByte()
        reply[3] = 0x83.toByte() // response, recursion available, NXDOMAIN
        reply[6] = 0; reply[7] = 0
        reply[8] = 0; reply[9] = 0
        reply[10] = 0; reply[11] = 0
        return reply
    }

    private fun u16(b: ByteArray, p: Int) = ((b[p].toInt() and 255) shl 8) or (b[p + 1].toInt() and 255)
    private fun put16(b: ByteArray, p: Int, v: Int) { b[p] = (v ushr 8).toByte(); b[p + 1] = v.toByte() }
    private fun checksum(b: ByteArray, start: Int, len: Int): Int {
        var sum = 0L
        var i = start
        while (i < start + len - 1) { sum += u16(b, i); i += 2 }
        if ((len and 1) == 1) sum += (b[start + len - 1].toInt() and 255) shl 8
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun stopVpn() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}
